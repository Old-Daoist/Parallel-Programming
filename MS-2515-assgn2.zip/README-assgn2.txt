Assignment 2 - Parallel Numerical Integration using Simpson's 3/8 Rule

Files:
- MS-2515-assgn2.cpp: C++ MPI source code
- MS-2515-assgn2-input.txt: sample file input

Compile:
mpic++ MS-2515-assgn2.cpp -o assgn2

Run:
mpiexec -n 4 ./assgn2

Choose 1 for keyboard input or 2 for file input.
For file input, enter the input filename. The sample file format is:
number_of_interval_cases
interval1 interval2 ... intervalN

Example file:
3
16 24 36

The integrand and integration limits remain fixed as required by the assignment:
integral from 0 to 4 of x^2 * exp(-x).
Intervals divisible by 3 are evaluated using composite Simpson's 3/8 rule.
Other positive interval counts are reported as not applicable and skipped.
