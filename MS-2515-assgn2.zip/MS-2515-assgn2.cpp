#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include <mpi.h>

using namespace std;

double f(double x)
{
    return x * x * exp(-x);
}

double simpson38(double x0, double h)
{
    if (h <= 0)
        throw "Invalid step size!";

    return (3.0 * h / 8.0) *
           (f(x0) + 3.0 * f(x0 + h) +
            3.0 * f(x0 + 2.0 * h) + f(x0 + 3.0 * h));
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int caseCount = 0;
    int valid = 1;
    vector<int> intervals;

    if (rank == 0)
    {
        try
        {
            int mode;
            ifstream file;
            istream* input = &cin;

            cout << "Choose input method (1 = Keyboard, 2 = File): ";
            if (!(cin >> mode))
                throw "Invalid input method!";

            if (mode == 2)
            {
                string filename;
                cout << "Enter input filename: ";

                if (!(cin >> filename))
                    throw "Invalid filename!";

                file.open(filename);

                if (!file)
                    throw "Could not open input file!";

                input = &file;
            }
            else if (mode != 1)
            {
                throw "Please choose 1 or 2!";
            }

            if (mode == 1)
                cout << "Enter number of interval cases: ";

            if (!(*input >> caseCount))
                throw "Could not read number of interval cases!";

            if (caseCount <= 0)
                throw "Number of interval cases must be positive!";

            intervals.resize(caseCount);

            if (mode == 1)
                cout << "Enter the interval counts: ";

            for (int i = 0; i < caseCount; i++)
            {
                if (!(*input >> intervals[i]))
                    throw "Invalid or incomplete interval input!";

                if (intervals[i] <= 0)
                    throw "Interval counts must be positive!";
            }
        }
        catch (const char* msg)
        {
            cout << "Error: " << msg << endl;
            valid = 0;
        }
        catch (...)
        {
            cout << "Memory allocation failed!" << endl;
            valid = 0;
        }
    }

    MPI_Bcast(&valid, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (valid == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(&caseCount, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int setup = 1;

    try
    {
        intervals.resize(caseCount);
    }
    catch (...)
    {
        cout << "Process " << rank << ": Memory allocation failed!" << endl;
        setup = 0;
    }

    int all_setup = 0;

    MPI_Allreduce(&setup, &all_setup, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);

    if (all_setup == 0)
    {
        if (rank == 0)
            cout << "Setup failed. Program terminated." << endl;

        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(intervals.data(), caseCount, MPI_INT, 0, MPI_COMM_WORLD);

    double a = 0.0;
    double b = 4.0;
    double exact = 2.0 - 26.0 * exp(-4.0);

    if (rank == 0)
    {
        cout.setf(ios::fixed);
        cout.precision(10);
        cout << "\nParallel Numerical Integration\n";
        cout << "Simpson's 3/8 Rule\n";
        cout << "Integral: x^2 * e^(-x) from 0 to 4\n";
        cout << "Number of processors: " << size << endl;
        cout << "Exact value: " << exact << "\n\n";
    }

    for (int t = 0; t < caseCount; t++)
    {
        int n = intervals[t];

        if (n % 3 != 0)
        {
            if (rank == 0)
            {
                cout << "Intervals = " << n << endl;
                cout << "Simpson's 3/8 Rule cannot be applied.\n";
                cout << "Number of intervals must be divisible by 3.\n\n";
            }

            continue;
        }

        double h = (b - a) / n;
        int panels = n / 3;
        double localSum = 0.0;
        double totalSum = 0.0;
        int calc_valid = 1;

        try
        {
            for (int k = rank; k < panels; k += size)
            {
                double x0 = a + 3.0 * k * h;
                localSum += simpson38(x0, h);
            }
        }
        catch (const char* msg)
        {
            cout << "Process " << rank << ": " << msg << endl;
            calc_valid = 0;
        }
        catch (...)
        {
            cout << "Process " << rank << ": An error occurred!" << endl;
            calc_valid = 0;
        }

        int all_calc_valid = 0;

        MPI_Allreduce(
            &calc_valid,
            &all_calc_valid,
            1,
            MPI_INT,
            MPI_MIN,
            MPI_COMM_WORLD
        );

        if (all_calc_valid == 0)
        {
            if (rank == 0)
                cout << "Integration failed.\n\n";

            continue;
        }

        MPI_Reduce(
            &localSum,
            &totalSum,
            1,
            MPI_DOUBLE,
            MPI_SUM,
            0,
            MPI_COMM_WORLD
        );

        if (rank == 0)
        {
            cout << "Intervals = " << n << endl;
            cout << "Step size = " << h << endl;
            cout << "Integral = " << totalSum << endl;
            cout << "Absolute Error = "
                 << fabs(totalSum - exact) << "\n\n";
        }
    }

    MPI_Finalize();
    return 0;
}
