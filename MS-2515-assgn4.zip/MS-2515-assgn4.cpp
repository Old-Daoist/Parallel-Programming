#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <iomanip>
#include <mpi.h>

using namespace std;

void quickSort(vector<double>& numbers, int low, int high)
{
    int i = low;
    int j = high;
    double pivot = numbers[(low + high) / 2];

    while (i <= j)
    {
        while (numbers[i] < pivot)
            i++;

        while (numbers[j] > pivot)
            j--;

        if (i <= j)
        {
            double temp = numbers[i];
            numbers[i] = numbers[j];
            numbers[j] = temp;
            i++;
            j--;
        }
    }

    if (low < j)
        quickSort(numbers, low, j);

    if (i < high)
        quickSort(numbers, i, high);
}

void parallelQuickSort(vector<double>& numbers, MPI_Comm comm)
{
    int rank, size;

    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &size);

    long long localCount = (long long)numbers.size();
    long long totalCount = 0;

    MPI_Allreduce(&localCount, &totalCount, 1, MPI_LONG_LONG_INT,
                  MPI_SUM, comm);

    if (totalCount <= 1)
        return;

    if (size == 1)
    {
        quickSort(numbers, 0, (int)numbers.size() - 1);
        return;
    }

    double localPivot = 0.0;
    int hasData = 0;

    if (!numbers.empty())
    {
        localPivot = numbers[numbers.size() / 2];
        hasData = 1;
    }

    vector<double> pivots(size);
    vector<int> available(size);

    MPI_Allgather(&localPivot, 1, MPI_DOUBLE, pivots.data(), 1,
                  MPI_DOUBLE, comm);

    MPI_Allgather(&hasData, 1, MPI_INT, available.data(), 1,
                  MPI_INT, comm);

    vector<double> pivotValues;

    for (int i = 0; i < size; i++)
    {
        if (available[i] == 1)
            pivotValues.push_back(pivots[i]);
    }

    if (pivotValues.empty())
        return;

    quickSort(pivotValues, 0, (int)pivotValues.size() - 1);

    double pivot = pivotValues[pivotValues.size() / 2];

    int lowProcesses = size / 2;
    int highProcesses = size - lowProcesses;

    vector<vector<double>> buckets(size);
    int lowPosition = 0;
    int highPosition = 0;

    for (int i = 0; i < (int)numbers.size(); i++)
    {
        if (numbers[i] < pivot)
        {
            int destination = lowPosition % lowProcesses;
            buckets[destination].push_back(numbers[i]);
            lowPosition++;
        }
        else
        {
            int destination = lowProcesses + (highPosition % highProcesses);
            buckets[destination].push_back(numbers[i]);
            highPosition++;
        }
    }

    vector<int> sendCounts(size, 0);
    vector<int> receiveCounts(size, 0);
    vector<int> sendDisplacements(size, 0);
    vector<int> receiveDisplacements(size, 0);

    int totalSend = 0;

    for (int i = 0; i < size; i++)
    {
        sendCounts[i] = (int)buckets[i].size();
        sendDisplacements[i] = totalSend;
        totalSend += sendCounts[i];
    }

    vector<double> sendData(totalSend);
    int position = 0;

    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < (int)buckets[i].size(); j++)
        {
            sendData[position] = buckets[i][j];
            position++;
        }
    }

    MPI_Alltoall(sendCounts.data(), 1, MPI_INT,
                 receiveCounts.data(), 1, MPI_INT, comm);

    int totalReceive = 0;

    for (int i = 0; i < size; i++)
    {
        receiveDisplacements[i] = totalReceive;
        totalReceive += receiveCounts[i];
    }

    vector<double> receiveData(totalReceive);
    double dummy = 0.0;

    MPI_Alltoallv(
        sendData.empty() ? &dummy : sendData.data(),
        sendCounts.data(),
        sendDisplacements.data(),
        MPI_DOUBLE,
        receiveData.empty() ? &dummy : receiveData.data(),
        receiveCounts.data(),
        receiveDisplacements.data(),
        MPI_DOUBLE,
        comm
    );

    numbers.swap(receiveData);

    int color;

    if (rank < lowProcesses)
        color = 0;
    else
        color = 1;

    MPI_Comm newComm;

    MPI_Comm_split(comm, color, rank, &newComm);

    parallelQuickSort(numbers, newComm);

    MPI_Comm_free(&newComm);
}

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, size;

    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int N = 0;
    int valid = 1;
    string inputFile;
    string outputFile;
    vector<double> numbers;

    if (rank == 0)
    {
        try
        {
            int choice;

            cout << "Choose input method (1 = Keyboard, 2 = File): ";

            if (!(cin >> choice))
                throw "Invalid input choice!";

            if (choice == 1)
            {
                cout << "Enter number of real values: ";

                if (!(cin >> N) || N <= 0)
                    throw "Invalid number of values!";

                numbers.resize(N);

                cout << "Enter " << N << " real numbers: ";

                for (int i = 0; i < N; i++)
                {
                    if (!(cin >> numbers[i]))
                        throw "Invalid number entered!";
                }
            }
            else if (choice == 2)
            {
                cout << "Enter input file name: ";
                cin >> inputFile;

                ifstream input(inputFile);

                if (!input)
                    throw "Unable to open input file!";

                if (!(input >> N) || N <= 0)
                    throw "Invalid number of values in input file!";

                numbers.resize(N);

                for (int i = 0; i < N; i++)
                {
                    if (!(input >> numbers[i]))
                        throw "Input file does not contain enough valid numbers!";
                }

                input.close();
            }
            else
            {
                throw "Choose 1 for keyboard or 2 for file input!";
            }

            cout << "Enter output file name: ";
            cin >> outputFile;
        }
        catch (const char* message)
        {
            cout << "Error: " << message << endl;
            valid = 0;
        }
        catch (...)
        {
            cout << "Memory allocation or input error!" << endl;
            valid = 0;
        }
    }

    MPI_Bcast(&valid, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (valid == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    vector<int> sendCounts;
    vector<int> displacements;
    vector<double> localNumbers;

    int localCount = N / size;

    if (rank < N % size)
        localCount++;

    int setup = 1;

    try
    {
        localNumbers.resize(localCount);

        if (rank == 0)
        {
            sendCounts.resize(size);
            displacements.resize(size);

            int offset = 0;

            for (int i = 0; i < size; i++)
            {
                sendCounts[i] = N / size;

                if (i < N % size)
                    sendCounts[i]++;

                displacements[i] = offset;
                offset += sendCounts[i];
            }
        }
    }
    catch (...)
    {
        cout << "Process " << rank << ": Memory allocation failed!" << endl;
        setup = 0;
    }

    int allSetup = 0;

    MPI_Allreduce(&setup, &allSetup, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);

    if (allSetup == 0)
    {
        MPI_Finalize();
        return 1;
    }

    double dummy = 0.0;

    MPI_Scatterv(
        rank == 0 ? numbers.data() : nullptr,
        rank == 0 ? sendCounts.data() : nullptr,
        rank == 0 ? displacements.data() : nullptr,
        MPI_DOUBLE,
        localNumbers.empty() ? &dummy : localNumbers.data(),
        localCount,
        MPI_DOUBLE,
        0,
        MPI_COMM_WORLD
    );

    parallelQuickSort(localNumbers, MPI_COMM_WORLD);

    vector<int> receiveCounts;
    vector<int> receiveDisplacements;
    vector<double> sortedNumbers;
    int gatherReady = 1;

    if (rank == 0)
    {
        try
        {
            receiveCounts.resize(size);
            receiveDisplacements.resize(size);
            sortedNumbers.resize(N);
        }
        catch (...)
        {
            cout << "Memory allocation failed while collecting sorted data!" << endl;
            gatherReady = 0;
        }
    }

    int localSortedCount = (int)localNumbers.size();

    MPI_Bcast(&gatherReady, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (gatherReady == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Gather(
        &localSortedCount,
        1,
        MPI_INT,
        rank == 0 ? receiveCounts.data() : nullptr,
        1,
        MPI_INT,
        0,
        MPI_COMM_WORLD
    );

    if (rank == 0)
    {
        int offset = 0;

        for (int i = 0; i < size; i++)
        {
            receiveDisplacements[i] = offset;
            offset += receiveCounts[i];
        }
    }

    MPI_Gatherv(
        localNumbers.empty() ? &dummy : localNumbers.data(),
        localSortedCount,
        MPI_DOUBLE,
        rank == 0 ? sortedNumbers.data() : nullptr,
        rank == 0 ? receiveCounts.data() : nullptr,
        rank == 0 ? receiveDisplacements.data() : nullptr,
        MPI_DOUBLE,
        0,
        MPI_COMM_WORLD
    );

    if (rank == 0)
    {
        try
        {
            ofstream output(outputFile);

            if (!output)
                throw "Unable to open output file!";

            output << sortedNumbers.size() << endl;
            output << fixed << setprecision(6);

            for (int i = 0; i < (int)sortedNumbers.size(); i++)
                output << sortedNumbers[i] << endl;

            output.close();

            cout << "Sorting completed successfully." << endl;
            cout << "Number of values: " << N << endl;
            cout << "Sorted data saved in: " << outputFile << endl;
        }
        catch (const char* message)
        {
            cout << "Error: " << message << endl;
        }
        catch (...)
        {
            cout << "Error while writing output file!" << endl;
        }
    }

    MPI_Finalize();

    return 0;
}
