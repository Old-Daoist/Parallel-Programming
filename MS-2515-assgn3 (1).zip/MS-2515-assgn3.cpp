#include <iostream>
#include <fstream>
#include <vector>
#include <mpi.h>

using namespace std;

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int n = 0, m = 0;
    int valid = 1;
    int mode = 0;

    vector<double> matrix;
    vector<double> vec;

    if (rank == 0)
    {
        try
        {
            cout << "Choose input method (1 = Keyboard, 2 = File): ";

            if (!(cin >> mode))
                throw "Invalid input method!";

            istream* input = &cin;
            ifstream inputFile;

            if (mode == 2)
            {
                inputFile.open("MS-2515-assgn3-input.txt");

                if (!inputFile)
                    throw "Unable to open input file!";

                input = &inputFile;
            }
            else if (mode != 1)
            {
                throw "Choose 1 for keyboard or 2 for file!";
            }

            if (!(*input >> n >> m))
                throw "Unable to read matrix dimensions!";

            if (n <= 0 || m <= 0)
                throw "Matrix dimensions must be positive!";

            if ((long long)n * m > 2147483647LL)
                throw "Matrix is too large for MPI communication!";

            matrix.resize(n * m);
            vec.resize(m);

            for (int i = 0; i < n * m; i++)
            {
                if (!(*input >> matrix[i]))
                    throw "Unable to read matrix elements!";
            }

            for (int i = 0; i < m; i++)
            {
                if (!(*input >> vec[i]))
                    throw "Unable to read vector elements!";
            }
        }
        catch (const char* msg)
        {
            cout << "Error: " << msg << endl;
            valid = 0;
        }
        catch (...)
        {
            cout << "Memory allocation failed!" << endl;
            valid = 0;
        }
    }

    MPI_Bcast(&valid, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (valid == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);

    vector<int> rowCounts(size);
    vector<int> rowDisplacements(size);
    vector<int> matrixCounts(size);
    vector<int> matrixDisplacements(size);

    vector<double> localMatrix;
    vector<double> localResult;
    vector<double> result;

    int setup = 1;
    int localRows = 0;

    try
    {
        int base = n / size;
        int remainder = n % size;
        int offset = 0;

        for (int i = 0; i < size; i++)
        {
            rowCounts[i] = base;

            if (i < remainder)
                rowCounts[i]++;

            rowDisplacements[i] = offset;
            matrixCounts[i] = rowCounts[i] * m;
            matrixDisplacements[i] = offset * m;
            offset += rowCounts[i];
        }

        localRows = rowCounts[rank];

        vec.resize(m);
        localMatrix.resize(matrixCounts[rank]);
        localResult.resize(localRows);

        if (rank == 0)
            result.resize(n);
    }
    catch (...)
    {
        cout << "Process " << rank << ": Memory allocation failed!" << endl;
        setup = 0;
    }

    int allSetup = 0;

    MPI_Allreduce(&setup, &allSetup, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);

    if (allSetup == 0)
    {
        if (rank == 0)
            cout << "Unable to prepare data for calculation!" << endl;

        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(vec.data(), m, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    MPI_Scatterv(
        rank == 0 ? matrix.data() : nullptr,
        matrixCounts.data(),
        matrixDisplacements.data(),
        MPI_DOUBLE,
        localMatrix.data(),
        matrixCounts[rank],
        MPI_DOUBLE,
        0,
        MPI_COMM_WORLD
    );

    for (int i = 0; i < localRows; i++)
    {
        localResult[i] = 0.0;

        for (int j = 0; j < m; j++)
        {
            localResult[i] += localMatrix[i * m + j] * vec[j];
        }
    }

    MPI_Gatherv(
        localResult.data(),
        localRows,
        MPI_DOUBLE,
        rank == 0 ? result.data() : nullptr,
        rowCounts.data(),
        rowDisplacements.data(),
        MPI_DOUBLE,
        0,
        MPI_COMM_WORLD
    );

    if (rank == 0)
    {
        try
        {
            ofstream outputFile("MS-2515-assgn3-output.txt");

            if (!outputFile)
                throw "Unable to create output file!";

            outputFile << n << " 1\n";

            cout << "\nMatrix-Vector Product (" << n << " x 1):\n";

            for (int i = 0; i < n; i++)
            {
                outputFile << result[i] << endl;
                cout << result[i] << endl;
            }

            outputFile.close();

            if (!outputFile)
                throw "Error while writing output file!";

            cout << "\nResult saved in MS-2515-assgn3-output.txt\n";
        }
        catch (const char* msg)
        {
            cout << "Error: " << msg << endl;
        }
        catch (...)
        {
            cout << "An error occurred while writing the output file!" << endl;
        }
    }

    MPI_Finalize();

    return 0;
}
