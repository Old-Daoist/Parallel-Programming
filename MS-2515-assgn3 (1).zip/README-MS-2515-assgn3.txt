Assignment 3 - Parallel Matrix-Vector Multiplication
Roll number: MS-2515

Files in this ZIP:
- MS-2515-assgn3.cpp             C++ MPI source code
- MS-2515-assgn3-input.txt       Sample 12 x 9 matrix and 9 x 1 vector
- MS-2515-assgn3-output.txt      Expected result vector (12 x 1)

Input format:
1. First line: n and m
2. Next n*m values: matrix elements in row-major order
3. Next m values: vector elements

The program supports keyboard input and file input. For the supplied test,
choose option 2 when prompted. The program reads MS-2515-assgn3-input.txt
from the current working directory and writes the result to
MS-2515-assgn3-output.txt.

Compile:
mpic++ MS-2515-assgn3.cpp -o assgn3

Run with the required three processors:
mpiexec -n 3 ./assgn3

On Windows:
mpiexec -n 3 .\assgn3.exe

At the prompt, enter 2 to read the supplied input file.
The matrix rows are distributed among the MPI processes using MPI_Scatterv.
The vector is shared using MPI_Bcast, and the result rows are collected using
MPI_Gatherv. The number of processes is obtained at runtime.
