#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <mpi.h>

using namespace std;

int main(int argc, char* argv[])
{
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int N = 0;
    int valid = 1;
    vector<long long> numbers;

    if (rank == 0)
    {
        try
        {
            int mode;
            ifstream file;
            istream* input = &cin;

            cout << "Choose input method (1 = Keyboard, 2 = File): ";
            if (!(cin >> mode))
                throw "Invalid input method!";

            if (mode == 2)
            {
                string filename;
                cout << "Enter input filename: ";

                if (!(cin >> filename))
                    throw "Invalid filename!";

                file.open(filename);

                if (!file)
                    throw "Could not open input file!";

                input = &file;
            }
            else if (mode != 1)
            {
                throw "Please choose 1 or 2!";
            }

            if (mode == 1)
                cout << "Enter number of elements: ";

            if (!(*input >> N))
                throw "Could not read number of elements!";

            if (N < 0)
                throw "Number of elements cannot be negative!";

            numbers.resize(N);

            if (mode == 1)
                cout << "Enter " << N << " numbers: ";

            for (int i = 0; i < N; i++)
            {
                if (!(*input >> numbers[i]))
                    throw "Invalid or incomplete number input!";
            }
        }
        catch (const char* msg)
        {
            cout << "Error: " << msg << endl;
            valid = 0;
        }
        catch (...)
        {
            cout << "Memory allocation failed!" << endl;
            valid = 0;
        }
    }

    MPI_Bcast(&valid, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (valid == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    vector<int> counts;
    vector<int> displacements;
    vector<long long> local_numbers;

    int local_count = 0;
    int setup = 1;

    try
    {
        counts.resize(size);
        displacements.resize(size);

        int base = N / size;
        int remainder = N % size;
        int offset = 0;

        for (int i = 0; i < size; i++)
        {
            counts[i] = base;

            if (i < remainder)
                counts[i]++;

            displacements[i] = offset;
            offset += counts[i];
        }

        local_count = counts[rank];
        local_numbers.resize(local_count);
    }
    catch (...)
    {
        cout << "Process " << rank << ": Memory allocation failed!" << endl;
        setup = 0;
    }

    int all_setup = 0;

    MPI_Allreduce(&setup, &all_setup, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);

    if (all_setup == 0)
    {
        if (rank == 0)
            cout << "Setup failed. Program terminated." << endl;

        MPI_Finalize();
        return 1;
    }

    MPI_Scatterv(
        rank == 0 ? numbers.data() : nullptr,
        counts.data(),
        displacements.data(),
        MPI_LONG_LONG_INT,
        local_numbers.data(),
        local_count,
        MPI_LONG_LONG_INT,
        0,
        MPI_COMM_WORLD
    );

    long long local_sum = 0;

    for (int i = 0; i < local_count; i++)
        local_sum += local_numbers[i];

    vector<long long> partial_sums;
    int gather_valid = 1;

    if (rank == 0)
    {
        try
        {
            partial_sums.resize(size);
        }
        catch (...)
        {
            cout << "Memory allocation failed!" << endl;
            gather_valid = 0;
        }
    }

    MPI_Bcast(&gather_valid, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (gather_valid == 0)
    {
        MPI_Finalize();
        return 1;
    }

    MPI_Gather(
        &local_sum,
        1,
        MPI_LONG_LONG_INT,
        rank == 0 ? partial_sums.data() : nullptr,
        1,
        MPI_LONG_LONG_INT,
        0,
        MPI_COMM_WORLD
    );

    if (rank == 0)
    {
        long long total_sum = 0;

        cout << "\nParallel Addition Results\n";

        for (int i = 0; i < size; i++)
        {
            cout << "Processor " << i
                 << " received " << counts[i]
                 << " elements. Partial sum = "
                 << partial_sums[i] << endl;

            total_sum += partial_sums[i];
        }

        cout << "\nFinal Sum = " << total_sum << endl;
    }

    MPI_Finalize();
    return 0;
}
