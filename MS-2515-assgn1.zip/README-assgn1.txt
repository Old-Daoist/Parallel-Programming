Assignment 1 - Parallel Addition using MPI and C++

Files:
- MS-2515-assgn1.cpp: C++ MPI source code
- MS-2515-assgn1-input.txt: sample file input

Compile:
mpic++ MS-2515-assgn1.cpp -o assgn1

Run:
mpiexec -n 4 ./assgn1

Choose 1 for keyboard input or 2 for file input.
For file input, enter the input filename. The sample file format is:
N
number1 number2 ... numberN

Example file:
10
1 2 3 4 5 6 7 8 9 10
